<?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
       
        // Recuperamos las frases Que se  ingresaron
        $Texto = trim($_POST['Texto']);
        

        // Contador de palabras
        $palabras = str_word_count($Texto);

        
        // se muestra el resultado
        echo "<div class='result'>El Texto ingresado tiene <strong>$palabras</strong> palabras.</div>";
    }
    ?>