<?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Recuperar los valores ingresados
        $numero1 = $_POST['numero1'];
        $numero2 = $_POST['numero2'];
        $operacion = $_POST['operacion'];
        
        // Inicializar el resultado
        $resultado = null;

        // Realizar el cálculo basado en la operación seleccionada
        switch ($operacion) {
            case 'suma':
                $resultado = $numero1 + $numero2;
                break;
            case 'resta':
                $resultado = $numero1 - $numero2;
                break;
            case 'multiplicacion':
                $resultado = $numero1 * $numero2;
                break;
            case 'division':
                if ($numero2 != 0) {
                    $resultado = $numero1 / $numero2;
                } else {
                    $resultado = 'Error: División por cero';
                }
                break;
            default:
                $resultado = 'Selecciona una operación';
                break;
        }

        // Mostrar el resultado
        echo "<div class='result'>El resultado de la <strong>$operacion</strong> es: <strong>$resultado</strong></div>";
    }
    ?>